# Notes: What Drives Tip Amount?

## Model
A Linear Regression model was trained to predict `tip` using `total_bill`,
`size`, `sex`, `smoker`, `day`, and `time`.

## Performance
- **Mean Squared Error (MSE): 1.173**
- **R-squared: 0.519** → the model explains about 52% of the variation in tips

## Most Influential Variable: `total_bill`
As per the standardized coefficients:

| Feature | Coefficient |
|---|---|
| total_bill | 0.841 |
| size | 0.168 |
| day_Thur | -0.068 |
| day_Sat | -0.058 |
| smoker_Yes | -0.040 |
| time_Lunch | 0.030 |
| sex_Male | -0.016 |
| day_Sun | -0.011 |

**`total_bill` is the most influential variable** — its effect is about
5x times tah, `size`. Others (day, smoker
status, sex, time) contributes abit.

## Takeaway
The bigger the bill, the bigger the tip. Party size has a quite small
effect. Day of week, smoking status, sex, and time of day doesnt matter much!
