# Tip Prediction — Simple regression Analysis

## Files
- `Bodhi Global Analysis.ipynb` — loads the data, trains the model, prints performance metrics, and saves the chart
- `tips.csv` — dataset (total_bill, tip, sex, smoker, day, time, size)
- `Notes.md` — write-up of findings

## How to run

1. Install dependencies:
   ```
   pip install pandas numpy scikit-learn matplotlib seaborn
   ```

2. Make sure `tips.csv` is in the same folder as `Bodhi Global Analysis.ipynb`.

3. Run the script:
   ```
   python Bodhi Global Analysis.ipynb
   ```

4. Output:
   - Model performance (MSE, R²)
   - Feature importance 
   - Evaluation and feature importance including a visual
